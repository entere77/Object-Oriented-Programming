public class Hello {
    public static void main(String[] args) {
        System.out.println("휴먼지능정보공학과");
        System.out.println("김종한");
        System.out.println("201910792");
    }
}

